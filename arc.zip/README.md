# about_me

A responsive "one page" about me and my projects. The site has been created by me in a minimalist style. 
The website contains helpful JavaScript solutions and CSS3 animations. You can contact me through contact form which is linked with Firebase

# Used technologies:

    HTML 5
    CSS 3
    Sass
    Firebase
    RWD
    JavaScript
    Bootstrap 4
    npm (task runner)
